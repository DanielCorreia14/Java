/*
Crie um programa chamado MovimentoVendaProduto. Crie duas vendas, uma com c�digo 1, Produto Carro1, 
Cliente Jo�o, quantidade 10, valor unit�rio 15000, percentual 10% e percentual de financiamento 10%; 
e outra com c�digo 2, Produto Carro2, Cliente Maria, quantidade 10, valor unit�rio 15000, percentual 10% e bonus 5000. 
Mostre os dados de ambos as vendas. 
Altere o percentual de financiamento para 15% e altere o percentual do Carro2 para 15%. 
Mostre os dados. 
Altere o b�nus para 6000. Mostre os dados do Carro2.*/
class  MovimentoVendaProduto
{public static void main (String [ ] args) throws Exception
{	VendaProdutoFinanciado venda1 = new VendaProdutoFinanciado( 1, ":Carro 1", "Joao", 10, 15000, 10,10);
	VendaProdutoBonus venda2 = new VendaProdutoBonus(2,":Carro 2", " :Maria", 10, 15000, 10, 5000);
	venda1.mostrarDados();
	venda2.mostrarDados();
	System.out.println("--------\t Alteracao de percentual\t --------");
	venda1.setPercentualFinanciamento(15);
	venda2.setPercentual(15);
	venda1.mostrarDados();
	venda2.mostrarDados();
	System.out.println("--------\t Alteracao de bonus\t --------");
	venda2.setBonus(6000);
	venda2.mostrarDados();






}//main

}//class
