/*Crie uma classe VendaProdutoFinanciado encapsulada (como subclasse de VendaProduto). 
Esta classe tem o novo atributo percentual do financiamento (G/S). 
O construtor � conforme a super classe, inicializando tamb�m o novo atributo. 
O m�todo valor total (em R$) deve ser modificado, retornando o c�lculo (valor total * (1 � percentual do financiamento / 100f)). 
O mostrar dados deve exibir tamb�m, al�m dos demais atributos da super classe, o novo atributo percentual do financiamento.
*/
class VendaProdutoFinanciado extends VendaProduto 
{
	private float percentualfinanciamento;//G e S

	public VendaProdutoFinanciado(int  codigo,String nomedoproduto,String nomedocliente,float quantidade,float valorunitario,float percentual,
		float percentualfinanciamento){
			super (codigo, nomedoproduto, nomedocliente, quantidade, valorunitario, percentual);
			this.percentualfinanciamento = percentualfinanciamento;}
		
		//override
		public float ValorTotal (){
		return (super.ValorTotal() * (1-this.percentualfinanciamento/100f));}
		
		public float getPercentualFinanciamento(){return this.percentualfinanciamento;}
		public void setPercentualFinanciamento(float percentualfinanciamento){this.percentualfinanciamento = percentualfinanciamento;}

		
		public void mostrarDados(){
		System.out.println("\n  codigo "+super.getCodigo()+
			"\n nome do produto " + super.getNomeDoProduto()+
			"\n nome do cliente " + super.getNomeDoCliente()+
			"\n quantidade " + super.getQuantidade()+
			"\n valor unitario " + super.getValorUnitario()+
			"\n percentual em (%) " + super.getPercentual()+
			"\n valor total: "+ ValorTotal()+
			"\n percentual financiamento: " + getPercentualFinanciamento());}
			


}
