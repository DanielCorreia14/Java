/*Crie uma classe VendaProdutoBonus encapsulada (como subclasse de VendaProduto). 
Esta classe tem o novo atributo bonus (em R$) (G/S). 
O construtor � conforme a super classe, inicializando tamb�m o novo atributo. 
O m�todo valor total (em R$) deve ser modificado retornando o c�lculo ( valor total � b�nus). 
O mostrar dados deve exibir tamb�m, al�m dos demais atributos da super classe, o novo atributo bonus.*/
class VendaProdutoBonus extends VendaProduto
{
 private float bonus;
 public VendaProdutoBonus(int  codigo,String nomedoproduto,String nomedocliente,float quantidade,float valorunitario,float percentual,float bonus){
 super(codigo, nomedoproduto, nomedocliente, quantidade, valorunitario,percentual);
 this.bonus=bonus;}

public float getBonus(){return this.bonus;}
public void setBonus(float bonus){this.bonus=bonus;}

//override
public float ValorTotal (){
	
return(super.ValorTotal() - getBonus());}
public void mostrarDados(){
System.out.println("\n codigo "+super.getCodigo()+
			"\n nome do produto " + super.getNomeDoProduto()+
			"\n nome do cliente " + super.getNomeDoCliente()+
			"\n quantidade " + super.getQuantidade()+
			"\n valor unitario " + super.getValorUnitario()+
			"\n percentual em (%) " + super.getPercentual()+
			"\n bonus: " +this.getBonus()+
			"\n valor total: "+ ValorTotal());
			


}


}
	

