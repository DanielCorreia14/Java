/*Crie uma classe Abstrata encapsulada chamada VendaProduto que conter� os 
atributos codigo (G/S),nome do produto (String) (G/S), nome do cliente (String) (G/S), 
quantidade (G/S), valor unitario (em R$) (G) e percentual (em %) (G/S). 
Crie um construtor inicializando todos os atributos. 
Esta classe conter� tamb�m o m�todo valor total (em R$) retornando o c�lculo 
((quantidade * valor unit�rio) * (1 � percentual/100)). 
O m�todo mostrarDados deve mostrar todos os atributos e o valor total.*/
abstract class VendaProduto 
{		private int  codigo;//G e S
		private String nomedoproduto;//G e S
		private	String nomedocliente;// G e S
		private	float quantidade;// G e S
		private	float valorunitario;// G
		private	float percentual;//G e S

			public VendaProduto(int  codigo,String nomedoproduto,String nomedocliente,float quantidade,float valorunitario,float percentual){
			this.codigo = codigo;
			this.nomedoproduto = nomedoproduto;
			this.nomedocliente = nomedocliente;
			this.quantidade = quantidade;
			this.valorunitario=valorunitario;
			this.percentual = percentual;}
		
		public int getCodigo(){return this.codigo;	}
		public void setCodigo(int codigo){this.codigo = codigo;}
		
		public String getNomeDoProduto(){return this.nomedoproduto;}
		public void setNomedoProduto(String nomedoproduto){this.nomedoproduto = nomedoproduto;}

		public String getNomeDoCliente(){return this.nomedocliente;}
		public void setNomedoCliente(String nomedocliente){this.nomedocliente = nomedocliente;}

		public float getQuantidade(){return this.quantidade;}
		public void setQuantidade(float quantidade){this.quantidade = quantidade;}

		public float getValorUnitario(){return this.valorunitario;}

		public float getPercentual(){return this.percentual;}
		public void setPercentual(float percentual){this.percentual = percentual;}


		public float ValorTotal (){
		return ((this.quantidade * this.valorunitario) * (1-this.percentual/100));
		}
		public void mostrarDados(){
			System.out.println("\n codigo "+this.codigo+
			"\n nome do produto " + this.nomedoproduto+
			"\n nome do cliente " + this.nomedocliente+
			"\n quantidade " + this.quantidade+
			"\n valor unitario " + this.valorunitario+
			"\n percentual em (%) " + this.percentual+ 
			"\n valor total: "+ this.ValorTotal());	}

}
